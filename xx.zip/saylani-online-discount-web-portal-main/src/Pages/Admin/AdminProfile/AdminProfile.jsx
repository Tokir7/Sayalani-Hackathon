import React from 'react'

export const AdminProfile = () => {
  return (
    <div>AdminProfile</div>
  )
}
