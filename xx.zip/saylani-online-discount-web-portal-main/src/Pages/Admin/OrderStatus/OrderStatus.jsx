import React from 'react'

export const OrderStatus = () => {
  return (
    <div>OrderStatus</div>
  )
}
