import SaylaniLogo from '../assets/Logo.svg'
import ProfileIcon from '../assets/profileIcon.svg'
import sliderOne from '../assets/sliderOne.jpg'
import sliderTwo from '../assets/sliderTwo.jpg'
import sliderThree from '../assets/sliderThree.jpg'
import searchIcon from '../assets/SearchIcon.svg'
import proDuctImage from '../assets/ProductImage.svg'




export {
    SaylaniLogo,
    ProfileIcon,
    sliderOne,
    sliderTwo,
    sliderThree,
    searchIcon,
    proDuctImage
}